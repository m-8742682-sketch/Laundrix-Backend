/**
 * Scheduled Function: Grace Period Timeout
 */

import type { VercelRequest, VercelResponse } from '@vercel/node';
import { rtdb } from '../lib/firebase';
import { 
  getNextUser, 
  removeUserFromQueue, 
  updateNextUserId 
} from '../lib/queue';
import { 
  notifyRemovedFromQueue, 
  notifyYourTurn,
  sendAndStoreNotification 
} from '../lib/fcm';
import type { GracePeriod } from '../lib/types';

export default async function handler(
  req: VercelRequest,
  res: VercelResponse
): Promise<void> {
  const secretKey = req.headers['x-cron-secret'] || req.query.secret;
  if (secretKey !== process.env.CRON_SECRET_KEY) {
    res.status(401).json({ success: false, error: 'Unauthorized' });
    return;
  }

  try {
    const now = new Date().toISOString();
    const processed: string[] = [];
    const errors: string[] = [];

    const gracePeriodsRef = rtdb.ref('gracePeriods');
    const snapshot = await gracePeriodsRef.get();

    if (!snapshot.exists()) {
      res.status(200).json({ success: true, message: 'No active grace periods', processed: [] });
      return;
    }

    const gracePeriods = snapshot.val() as Record<string, GracePeriod>;

    for (const [machineId, gracePeriod] of Object.entries(gracePeriods)) {
      try {
        if (gracePeriod.status !== 'active') continue;
        if (gracePeriod.expiresAt > now) continue;

        console.log(`[Cron] Processing expired grace period for ${machineId}`);

        await rtdb.ref(`gracePeriods/${machineId}`).update({
          status: 'expired',
          expiredAt: now,
          expiredBy: 'cron'
        });

        await removeUserFromQueue(machineId, gracePeriod.userId);

        await notifyRemovedFromQueue(gracePeriod.userId, machineId);
        await sendAndStoreNotification({
          userId: gracePeriod.userId,
          type: 'removed_from_queue',
          title: '❌ Removed from Queue',
          body: `You were removed from Machine ${machineId} queue due to timeout.`,
          data: { machineId },
          priority: 'normal'
        });

        await updateNextUserId(machineId);

        const nextUser = await getNextUser(machineId);
        if (nextUser) {
          const newGraceRef = rtdb.ref(`gracePeriods/${machineId}`);
          const newStartedAt = new Date();
          const newWarningAt = new Date(newStartedAt.getTime() + 2 * 60 * 1000);
          const newExpiresAt = new Date(newStartedAt.getTime() + 5 * 60 * 1000);

          await newGraceRef.set({
            machineId,
            userId: nextUser.userId,
            startedAt: newStartedAt.toISOString(),
            warningAt: newWarningAt.toISOString(),
            expiresAt: newExpiresAt.toISOString(),
            warningSent: false,
            status: 'active',
          });

          await notifyYourTurn(nextUser.userId, machineId);
          await sendAndStoreNotification({
            userId: nextUser.userId,
            type: 'your_turn',
            title: '🎉 Your Turn!',
            body: `Machine ${machineId} is ready for you. You have 5 minutes!`,
            data: { machineId },
            sound: 'alarm',
            priority: 'high'
          });

          processed.push(`${machineId}: expired ${gracePeriod.userId}, promoted ${nextUser.userId}`);
        } else {
          await rtdb.ref(`gracePeriods/${machineId}`).remove();
          processed.push(`${machineId}: expired ${gracePeriod.userId}, queue empty`);
        }

      } catch (err: any) {  // FIXED: Add type annotation
        console.error(`[Cron] Error processing ${machineId}:`, err);
        errors.push(`${machineId}: ${err.message}`);
      }
    }

    res.status(200).json({
      success: true,
      message: `Processed ${processed.length} expired grace periods`,
      processed,
      errors: errors.length > 0 ? errors : undefined
    });

  } catch (error) {
    console.error('[Cron] Grace timeout error:', error);
    res.status(500).json({ success: false, error: 'Internal server error' });
  }
}
