import type { VercelRequest, VercelResponse } from '@vercel/node';
import { incidentsRef, getCommandsRef } from '../lib/firebase';
import { 
  sendAndStoreNotification 
} from '../lib/fcm';
import type { Incident } from '../lib/types';

export default async function handler(
  req: VercelRequest,
  res: VercelResponse
): Promise<void> {
  const secretKey = req.headers['x-cron-secret'] || req.query.secret;
  if (secretKey !== process.env.CRON_SECRET_KEY) {
    res.status(401).json({ success: false, error: 'Unauthorized' });
    return;
  }

  try {
    const now = new Date().toISOString();
    const processed: string[] = [];
    const errors: string[] = [];

    const expiredSnapshot = await incidentsRef
      .where('status', '==', 'pending')
      .where('expiresAt', '<=', now)
      .get();

    if (expiredSnapshot.empty) {
      res.status(200).json({ success: true, message: 'No expired incidents', processed: [] });
      return;
    }

    for (const doc of expiredSnapshot.docs) {
      try {
        const incident = doc.data() as Incident;
        const incidentId = doc.id;

        console.log(`[Cron] Processing expired incident ${incidentId}`);

        await incidentsRef.doc(incidentId).update({
          status: 'timeout',
          resolvedAt: now,
          buzzerTriggered: true,
          resolvedBy: 'cron'
        });

        const commandsRef = getCommandsRef(incident.machineId);
        await commandsRef.update({
          buzzer: true,
          buzzerAt: now,
          buzzerReason: 'incident_timeout'
        });

        await sendAndStoreNotification({
          userId: incident.intruderId,
          type: 'buzzer_triggered',
          title: '🚨 Alert Triggered',
          body: `Unauthorized access alert for Machine ${incident.machineId}.`,
          data: { machineId: incident.machineId, incidentId },
          priority: 'high'
        });

        await sendAndStoreNotification({
          userId: incident.nextUserId,
          type: 'buzzer_triggered',
          title: '🚨 Auto-Alert Triggered',
          body: `No response received. Buzzer activated for Machine ${incident.machineId}.`,
          data: { machineId: incident.machineId, incidentId }
        });

        processed.push(`${incidentId}: ${incident.machineId} - buzzer triggered`);

      } catch (err: any) {  // FIXED: Add type annotation
        console.error(`[Cron] Error processing incident ${doc.id}:`, err);
        errors.push(`${doc.id}: ${err.message}`);
      }
    }

    res.status(200).json({
      success: true,
      message: `Processed ${processed.length} expired incidents`,
      processed,
      errors: errors.length > 0 ? errors : undefined
    });

  } catch (error) {
    console.error('[Cron] Incident timeout error:', error);
    res.status(500).json({ success: false, error: 'Internal server error' });
  }
}